# 📋 Comprehensive Skills List for MD BABU MIA, PhD

## Summary of Custom Claude Skills

Based on your profile as a Hematology/Medical Oncology Professor at Mount Sinai with expertise in single-cell multi-omics, bioinformatics, and MPN research.

---

## 1️⃣ bioinformatics-singlecell

**Trigger phrases:**
- "Analyze single-cell data"
- "scRNA-seq / scCITE-seq / scATAC-seq"
- "Cell type identification"
- "TotalVI integration"
- "UMAP clustering"
- "Differential expression in single cells"
- "Scanpy analysis"

**Core capabilities:**
- Complete scRNA-seq workflow (QC → normalization → clustering → annotation)
- CITE-seq protein + RNA integration with TotalVI
- Multi-batch integration and visualization
- Cell type marker libraries for hematopoiesis
- Publication-quality dot plots, UMAP, violin plots

---

## 2️⃣ ngs-analysis

**Trigger phrases:**
- "RNA-seq pipeline"
- "FASTQ processing"
- "Alignment with STAR/Salmon"
- "Differential expression DESeq2"
- "Variant calling"
- "GEO/SRA download"

**Core capabilities:**
- Complete bulk RNA-seq pipeline
- Quality control (FastQC, MultiQC, fastp)
- Alignment (STAR, BWA-MEM2)
- Quantification (featureCounts, Salmon)
- DESeq2/edgeR differential expression
- GATK somatic variant calling
- GEO/SRA data retrieval automation

---

## 3️⃣ python-package-builder

**Trigger phrases:**
- "Create pip package"
- "Convert script to package"
- "PyPI upload"
- "Package setup"
- "CLI tool development"
- "pyproject.toml"

**Core capabilities:**
- Modern pyproject.toml configuration
- CLI development with Click
- pytest testing framework
- GitHub Actions CI/CD
- PyPI/TestPyPI publishing
- Environment variable configuration

---

## 4️⃣ scientific-manuscript

**Trigger phrases:**
- "Write manuscript"
- "Discussion section"
- "Methods section"
- "Blood journal format"
- "Nature format"
- "Figure legend"
- "Statistical reporting"

**Core capabilities:**
- Journal-specific formatting (Blood, Nature, Cell)
- Structured abstract writing
- Methods with reproducibility standards
- Results with proper statistical reporting
- Discussion structure
- Figure legend templates
- HIPAA/IRB compliance language

---

## 5️⃣ data-visualization-biomedical

**Trigger phrases:**
- "Volcano plot"
- "Heatmap"
- "Publication figure"
- "Multi-panel figure"
- "Statistical annotation"
- "Export for journal"

**Core capabilities:**
- Publication-quality matplotlib settings
- Volcano plots with gene labels
- Hierarchically clustered heatmaps
- Scanpy enhanced visualizations
- Statistical significance annotations
- Multi-panel figure assembly
- Journal-ready exports (PDF, SVG, PNG at 300 DPI)

---

## 6️⃣ mpn-research-assistant

**Trigger phrases:**
- "MPN research"
- "Myelofibrosis"
- "JAK2 CALR MPL mutations"
- "PPM1D pathway"
- "Megakaryocyte markers"
- "Fibrosis genes"
- "MIPSS70 scoring"

**Core capabilities:**
- WHO 2022 MPN classification
- Driver mutation analysis (JAK2V617F, CALR types, MPL)
- HMR mutation cataloging
- PPM1D pathway expertise and therapeutic targets
- Megakaryocyte subtype markers
- Fibrosis gene signatures
- Clinical trial data interpretation (BOREAS, navtemadlin)
- Prognostic scoring (MIPSS70+ v2.0)

---

## 🔗 Skill Combinations

These skills are designed to work together:

| Task | Skills Used |
|------|-------------|
| MPN single-cell analysis | bioinformatics-singlecell + mpn-research-assistant |
| Blood journal figure | data-visualization-biomedical + scientific-manuscript |
| DEG visualization | ngs-analysis + data-visualization-biomedical |
| PPM1D manuscript | scientific-manuscript + mpn-research-assistant |
| Bioinformatics tool development | python-package-builder + ngs-analysis |

---

## 📁 File Locations

After installation:

```
~/.claude/skills/user/
├── bioinformatics-singlecell/SKILL.md
├── ngs-analysis/SKILL.md
├── python-package-builder/SKILL.md
├── scientific-manuscript/SKILL.md
├── data-visualization-biomedical/SKILL.md
└── mpn-research-assistant/SKILL.md
```

---

## 🎯 Quick Reference Commands

```bash
# List installed skills
ls ~/.claude/skills/user/

# View a skill
cat ~/.claude/skills/user/bioinformatics-singlecell/SKILL.md

# Update a skill
nano ~/.claude/skills/user/mpn-research-assistant/SKILL.md
```

---

*Generated for MD BABU MIA, PhD - Mount Sinai*
*December 2025*
